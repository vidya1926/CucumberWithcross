package testcase;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.opera.OperaDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Servicenow {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(options);
		
		
		//2.Load the url as " https://login.salesforce.com/ "
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			//3.Enter the username as " ramkumar.ramaiah@testleaf.com "
		driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
			//4. Enter the password as " Password$123 "
		driver.findElement(By.id("password")).sendKeys("Testleaf$321");
			//5.click on the login button
		driver.findElement(By.id("Login")).click();
	  Thread.sleep(2000);
		// Click on Global Actions SVG icon
		WebElement svg = driver.findElement(By.xpath("//div//*[local-name()='svg' and @class='slds-icon slds-icon_x-small']//*[local-name()='path']"));

		Actions act=new Actions(driver);
		act.moveToElement(svg).click(svg).perform();
		
		// Click on New Case
		WebElement nc = driver.findElement(By.xpath("//a[@title='New Case']"));
		driver.executeScript("arguments[0].click();", nc);
		// Choose Contact Name from the dropdown
		driver.findElement(By.xpath("(//input[@role='combobox'])[1]")).click();
		driver.findElement(By.xpath("(//div[contains(@class,'primaryLabel')])[1]")).click();
        // Select status as Escalated
		WebElement status = driver.findElement(By.xpath("//a[text()='New']"));
		driver.executeScript("arguments[0].click();", status);	
		WebElement esc = driver.findElement(By.xpath("//a[text()='Escalated']"));
		driver.executeScript("arguments[0].click();", esc);
		//8) Enter Subject as 'Testing' and description as 'Dummy'
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys("Testing");
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).sendKeys("Dummy");
        //9) Click 'Save' and verify the message
        driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		String text = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();

         if(text.contains(" was created")) {
        	 System.out.println("case was created");
         }
         else {
        	 System.err.println("case Not created");
         }
	}

}
